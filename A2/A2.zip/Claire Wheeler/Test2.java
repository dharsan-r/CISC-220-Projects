package ca.queensu.cs;

public class Test2 {

    public Test2() {
    }

    public void test2Method(int x) {
    }

    public  static  void  oops  (int x) {
        // oops(x - 1);
    }
}

